﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using StudentsPersonalData.Pages;
using StudentsPersonalData.Classes;

namespace StudentsPersonalData.Pages
{
    public partial class PageStudents : Page
    {
        public PageStudents()
        {
            InitializeComponent();
            DGridUsers.ItemsSource = ZNAKEntities.GetContext().ZNAK.ToList();
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        //Редактирование пользователей
        {
            ClassFrame.frmObj.Navigate(new AddEditPagq((sender as Button).DataContext as ZNAK));
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        // Добавление пользователей
        {
            ClassFrame.frmObj.Navigate(new AddEditPagq(null)/*((Person)DGridUsers.SelectedItem)*/);
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            //Удаление нескольких пользователей
            var personForRemoving = DGridUsers.SelectedItems.Cast<ZNAK>().ToList();
            if (MessageBox.Show($"Удалить {personForRemoving.Count()} пользователей?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    ZNAKEntities.GetContext().ZNAK.RemoveRange(personForRemoving);
                    ZNAKEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены");
                    DGridUsers.ItemsSource = ZNAKEntities.GetContext().ZNAK.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }


        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            DGridUsers.ItemsSource = ZNAKEntities.GetContext().ZNAK.Where(x => x.Zodiac.ToLower().Contains(TxtSearch.Text)).ToList();
        }


            private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {//Динамиеское отображение добавленных или изменённых данных
            if (Visibility == Visibility.Visible)
            {
                ZNAKEntities.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DGridUsers.ItemsSource = ZNAKEntities.GetContext().ZNAK.ToList();
            }
        }
    }
}