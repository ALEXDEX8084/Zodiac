﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using StudentsPersonalData.Classes;

namespace StudentsPersonalData.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditPagq.xaml
    /// </summary>
    public partial class AddEditPagq : Page
    {
        private ZNAK _currentperson = new ZNAK(); //экземпляр добавляемого пользователя
        public AddEditPagq(ZNAK selectedUser) // в конструктор добавлен праметр типа User
        {
            InitializeComponent();
            if (selectedUser != null)
                _currentperson = selectedUser;
            DataContext = _currentperson;
        }

        private void Savebtn_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();// Объект для сообщение об ошибке
            //проверка полей объекта
            if (string.IsNullOrWhiteSpace(_currentperson.FIO))
                error.AppendLine("Укажите ФИО");
            if (string.IsNullOrWhiteSpace(_currentperson.Zodiac))
                error.AppendLine("Укажите Знак зодиака");
            if (string.IsNullOrWhiteSpace(Datebrith.Text))
                error.AppendLine("Укажите Дату рождения");
            if (error.Length > 0)

            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentperson.IDZNAK == 0)
                ZNAKEntities.GetContext().ZNAK.Add(_currentperson);//Добавить в контекст
            try
            {

                ZNAKEntities.GetContext().SaveChanges();// Сохранить изменения
                MessageBox.Show("Данные сохраненны");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }
    }

}

